package com.samsugn.challenge.samsungcodingchallenge;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

/**
 * Created by levin on 5/10/17.
 */

public class MainActivityImageListAdapter extends RecyclerView.Adapter<MainActivityImageListAdapter.MainActivityImageListViewHolder> {

    public interface OnItemClickListener {
        void onCategoryItemClick(String categoryName);
        void onCategoryItemLongClick(String categoryName);
    }

    private final List<ImageManager.ImageDescription> mImageDescriptionList;
    private final OnItemClickListener mListener;

    public MainActivityImageListAdapter(List<ImageManager.ImageDescription> imageDescriptionList, OnItemClickListener listener) {
        mImageDescriptionList = imageDescriptionList;
        mListener = listener;
    }

    @Override
    public MainActivityImageListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.main_acitivity_image_list_item_layout, parent, false);
        return new MainActivityImageListViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MainActivityImageListViewHolder holder, int position) {
        final ImageManager.ImageDescription imageDescription = mImageDescriptionList.get(position);
        holder.categoryName.setText(imageDescription.categoryName);
        holder.categoryImage.setImageDrawable(imageDescription.image);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mListener != null) {
                    mListener.onCategoryItemClick(imageDescription.categoryName);
                }
            }
        });
        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (mListener != null) {
                    mListener.onCategoryItemLongClick(imageDescription.categoryName);
                }
                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return mImageDescriptionList.size();
    }

    public static class MainActivityImageListViewHolder extends RecyclerView.ViewHolder {

        TextView categoryName;
        ImageView categoryImage;

        public MainActivityImageListViewHolder(View view) {
            super(view);
            categoryName = (TextView) view.findViewById(R.id.category_name);
            categoryImage = (ImageView) view.findViewById(R.id.category_image);
        }
    }
}
