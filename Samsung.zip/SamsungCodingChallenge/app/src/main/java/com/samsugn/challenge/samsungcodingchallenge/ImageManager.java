package com.samsugn.challenge.samsungcodingchallenge;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.drawable.Drawable;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by levin on 5/10/17.
 */

public class ImageManager {

    private static final String CATEGORIES_FOLDER_PATH = "categories";
    private static ImageManager sInstance;

    //private Context mContext;
    private AssetManager mAssetManager;

    private List<ImageDescription> mCategoryList;
    private Map<String, List<ImageDescription>> mCategoryImageMap;

    public static ImageManager getInstance() {
        if (sInstance == null) {
            throw new RuntimeException("ImageManager was not initialized!");
        }
        return sInstance;
    }

    public static void initialize(Context context) {
        if (sInstance == null) {
            sInstance = new ImageManager(context);
        }
    }

    private ImageManager(Context context) {
        mAssetManager = context.getAssets();
    }

    public List<ImageDescription> getCategoryList() {
        if (mCategoryList == null) {
            mCategoryList = new ArrayList<>();
            mCategoryImageMap = new HashMap<>();

            try {
                String[] categoryList = mAssetManager.list(CATEGORIES_FOLDER_PATH);
                for (String categoryName : categoryList) {

                    String[] categoryImageFileNameList = mAssetManager.list(CATEGORIES_FOLDER_PATH + "/" + categoryName);
                    ImageDescription imageDescription = new ImageDescription();
                    imageDescription.categoryName = categoryName;
                    imageDescription.image = getDrawable(CATEGORIES_FOLDER_PATH + "/" + categoryName + "/" + categoryImageFileNameList[0]);

                    List<ImageDescription> categoryImageList = new ArrayList<>();
                    for (String imageFileName : categoryImageFileNameList) {
                        ImageDescription categoryImageDescription = new ImageDescription();
                        categoryImageDescription.categoryName = categoryName;
                        categoryImageDescription.imageFileName = imageFileName;
                        categoryImageList.add(categoryImageDescription);
                    }
                    mCategoryImageMap.put(categoryName, categoryImageList);

                    mCategoryList.add(imageDescription);

                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return mCategoryList;
    }

    public List<ImageDescription> getImageListForCategory(String categoryName) {
        List<ImageDescription> result = mCategoryImageMap.get(categoryName);

        for (ImageDescription imageDescription : result) {
            imageDescription.image = getDrawable(CATEGORIES_FOLDER_PATH + "/" + categoryName + "/" + imageDescription.imageFileName);
        }

        return result;
    }

    private Drawable getDrawable(String path) {
        try {
            InputStream ims = mAssetManager.open(path);
            return Drawable.createFromStream(ims, null);
        } catch (IOException ex) {
            throw new RuntimeException("Could not create a drawable");
        }
    }


    public static class ImageDescription {
        public String categoryName;
        public String imageFileName;
        public Drawable image;
    }
}
