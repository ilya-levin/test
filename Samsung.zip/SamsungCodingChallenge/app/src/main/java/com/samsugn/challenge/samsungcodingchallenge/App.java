package com.samsugn.challenge.samsungcodingchallenge;

import android.app.Application;

/**
 * Created by levin on 5/10/17.
 */

public class App extends Application {

    private static App mApp;

    public static App getApp() {
        return mApp;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mApp = this;

        ImageManager.initialize(this);

    }


}
