package com.samsugn.challenge.samsungcodingchallenge;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.util.List;

/**
 * Created by levin on 5/10/17.
 */

public class GalleryDialogAdapter extends RecyclerView.Adapter<GalleryDialogAdapter.GalleryDialogViewHolder> {

    private final List<ImageManager.ImageDescription> mImageDescriptionList;

    public GalleryDialogAdapter(List<ImageManager.ImageDescription> imageDescriptionList) {
        mImageDescriptionList = imageDescriptionList;
    }

    @Override
    public GalleryDialogViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.gallery_dialog_item_layout, parent, false);
        return new GalleryDialogViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(GalleryDialogViewHolder holder, int position) {
        final ImageManager.ImageDescription imageDescription = mImageDescriptionList.get(position);
        holder.image.setImageDrawable(imageDescription.image);
    }

    @Override
    public int getItemCount() {
        return mImageDescriptionList.size();
    }

    public static class GalleryDialogViewHolder extends RecyclerView.ViewHolder {
        ImageView image;

        public GalleryDialogViewHolder(View view) {
            super(view);
            image = (ImageView) view.findViewById(R.id.image);
        }
    }
}
