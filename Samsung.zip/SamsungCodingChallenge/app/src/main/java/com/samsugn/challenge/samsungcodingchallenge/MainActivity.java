package com.samsugn.challenge.samsungcodingchallenge;

import android.content.Intent;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import java.util.Collections;
import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;

public class MainActivity extends AppCompatActivity implements MainActivityImageListAdapter.OnItemClickListener {

    @InjectView(R.id.image_list)
    protected RecyclerView mImageRecyclerViewList;

    private MainActivityImageListAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.inject(this);
        initRecyclerView();
    }

    private void initRecyclerView() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        DividerItemDecoration dividerItemDecoration =
                new DividerItemDecoration(this, layoutManager.getOrientation());
        dividerItemDecoration.setDrawable(ContextCompat.getDrawable(this, R.drawable.list_divider));

        mImageRecyclerViewList.setHasFixedSize(true);
        mImageRecyclerViewList.setLayoutManager(layoutManager);
        mImageRecyclerViewList.addItemDecoration(dividerItemDecoration);

        mAdapter = new MainActivityImageListAdapter(ImageManager.getInstance().getCategoryList(), this);
        mImageRecyclerViewList.setAdapter(mAdapter);
    }

    @Override
    public void onCategoryItemClick(String categoryName) {
        Intent intent = new Intent(this, SecondActivity.class);
        Bundle bundle = new Bundle();
        bundle.putString(SecondActivity.KEY_CATEGORY_NAME, categoryName);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    @Override
    public void onCategoryItemLongClick(String categoryName) {
        FragmentManager fm = getSupportFragmentManager();
        //Collections.sort(transactionList, new TransactionsUtils.TransactionDateComparator());
        GalleryDialog dialog = new GalleryDialog(categoryName);
        dialog.show(fm, "gallery_dialog");
    }
}
