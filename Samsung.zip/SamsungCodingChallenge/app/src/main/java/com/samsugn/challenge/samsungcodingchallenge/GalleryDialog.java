package com.samsugn.challenge.samsungcodingchallenge;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatDialogFragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

/**
 * Created by levin on 5/10/17.
 */

public class GalleryDialog extends AppCompatDialogFragment {

    public static final String CATEGORY_NAME_PARAM = "category_name_param";

    public GalleryDialog() {
    }

    @SuppressLint("ValidFragment")
    public GalleryDialog(String categoryName) {
        Bundle args = new Bundle();
        args.putString(CATEGORY_NAME_PARAM, categoryName);
        setArguments(args);
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        super.onCreateDialog(savedInstanceState);

        String categoryName = getArguments().getString(CATEGORY_NAME_PARAM);

        View dialogView =
                getActivity().getLayoutInflater()
                        .inflate(R.layout.gallery_dialog_layout, null);

        RecyclerView recyclerView = (RecyclerView) dialogView.findViewById(R.id.list);

        initRecyclerView(recyclerView);
        recyclerView.setAdapter(new GalleryDialogAdapter(ImageManager.getInstance().getImageListForCategory(categoryName)));

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        builder.setView(dialogView);

        Dialog dialog = builder.create();


        return dialog;
    }

    @Override
    public void onResume() {
        super.onResume();

        int width = getResources().getDisplayMetrics().widthPixels;
        int height = getResources().getDisplayMetrics().heightPixels;

        int dimension = width < height ? width : height;

        getDialog().getWindow().setLayout(dimension, dimension);
    }

    private void initRecyclerView(RecyclerView recyclerView) {
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
        DividerItemDecoration dividerItemDecoration =
                new DividerItemDecoration(getActivity(), layoutManager.getOrientation());
        dividerItemDecoration.setDrawable(ContextCompat.getDrawable(getActivity(), R.drawable.list_divider));

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.addItemDecoration(dividerItemDecoration);
    }

}
