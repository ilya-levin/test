package com.samsugn.challenge.samsungcodingchallenge;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

/**
 * Created by levin on 5/10/17.
 */

public class SecondActivityImageListAdapter extends RecyclerView.Adapter<SecondActivityImageListAdapter.SecondActivityImageListViewHolder> {

    private final List<ImageManager.ImageDescription> mImageDescriptionList;

    public SecondActivityImageListAdapter(List<ImageManager.ImageDescription> imageDescriptionList) {
        mImageDescriptionList = imageDescriptionList;
    }

    @Override
    public SecondActivityImageListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.second_acitivity_image_list_item_layout, parent, false);
        return new SecondActivityImageListViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(SecondActivityImageListViewHolder holder, int position) {
        final ImageManager.ImageDescription imageDescription = mImageDescriptionList.get(position);
        holder.fileName.setText(imageDescription.imageFileName);
        holder.image.setImageDrawable(imageDescription.image);
    }

    @Override
    public int getItemCount() {
        return mImageDescriptionList.size();
    }

    public static class SecondActivityImageListViewHolder extends RecyclerView.ViewHolder {

        TextView fileName;
        ImageView image;

        public SecondActivityImageListViewHolder(View view) {
            super(view);
            fileName = (TextView) view.findViewById(R.id.file_name);
            image = (ImageView) view.findViewById(R.id.image);
        }
    }
}
